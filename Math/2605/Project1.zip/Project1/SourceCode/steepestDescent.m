function [ x ] = steepestDescent(A, b,x, accuracy)
%This function calculates a solution matrix x by using the Steepest Descent
%Algorithm
%
%Assuming we are solving the scenario Ax = b, it takes in an nxn matrix A,
%an nx1 matrix b, a starting point x (also nx1), and a desired accuracy as
%a decimal.  It then solves and returns the solution matrix (x).  If this
%is run in MATLAB, A, b, x, and the count will be displayed to the console.
% The code to draw the plots has also been commented out.  Remove the "%"
% at the beginning of lines 12, 13, 31, 32, and 36 to plot the curve as
% well.  This is how I generated the graphs in the write-up.

%X = [];
%Y = [];
if isempty(x) == 1
    x = [];
    [m,n] = size(A);
    for j = 1:m
        x = [x;1];
    end
end
A
b

newD = norm(-(A*x - b), 'fro');
count = 0;
while(newD >= accuracy) 
    dk = -(A*x-b);
    mag = (norm(dk, 'fro'))^2;
    x = x + ((mag)/(dot(dk, A*dk)))* dk;
    newD = norm(-(A*x - b), 'fro');
   % X = [X, count];
    %Y = [Y, newD];
    count = count + 1;

end
    %plot(X, Y)
   x
count
end

