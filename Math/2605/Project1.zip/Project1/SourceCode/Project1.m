try
str = inputdlg('What would you like to do?  Input 1 to use random matrices.  Input 2 to put matrices in yourself');
num = str2num(str{1});

if num == 2
    str = inputdlg('Input a list of numbers.  Use commas to put them in the same line and semicolons to add a new line.  For example 5,2;2,1 would have 5 and 2 in the first row and 2 and 1 in the second row, therefore forming a 2x2 matrix.  Understand that this program will only work for positive definite nxn matrices!');
    A = str2num(str{1});
    str = inputdlg('Good!  Now enter a matrix b (Ax = b) using the same format as before!  Example: 1;1 would lead to a 2x1 matrix with ones in both the first and second rows.  This matrix should always be nx1 where n is the number of rows in the first matrix you entered!');
    b = str2num(str{1});
    str = inputdlg('Now, enter the starting point that you wish to use.  This should also be an nx1 matrix where n is the number of rows in the first matrix you entered.  Example: 1;1 will be a 2x1 matrix with ones in both rows.  If you enter nothing, the program will default to using a column of ones to form an nx1 matrix.  This may lead to a solution that takes an extremely long amount of time.  So, choose a good starting point!');
    x = str2num(str{1});
    str =  inputdlg('Last thing! enter your desired accuracy as a decimal.  For example, 10^-5 would be 0.00001. I will generate a pop-up with the solution after this. Please maximize that window to see all the answers!');
    accuracy = str2double(str{1});
    
    [m,n] = size(A);
    [y,z] = size(b);

    if (m == n) && (m == y) && (z == 1)
        answer = steepestDescent(A,b,x, accuracy);
        hList = uicontrol('Style','text','Position', [100 100 200 200]);
        set(hList,'String',num2str(answer)); 
        return;
        %disp(answer)   
    else
        hList = uicontrol('Style','text','Position',[100 100 200 200]);
        set(hList,'String','You entered an invalid input.  Please close the program and try again');
        return;
    end
end

if num == 1
    str = inputdlg('Okay!  You have chosen to generate random matrices.  This will have to be a square matrix.  Give me a number n so I can generate an nxn matrix.  Example: enter 5 for a 5x5 matrix');
    n = str2num(str{1});
    str = inputdlg('Good!  Now, give me an upper bound for the values in the matrix.  Example: enter 10 to ensure that no values in the random matrix exceed 10.  The matrix B will be created after you enter this.  A will be created using A = transpose(B) * B');
    bound = str2num(str{1});
    B = randi(bound, n, n);
    A = transpose(B) * B;
    str = inputdlg('Done!  Almost finished.  What would you the upper bound for b (in Ax = b) to be?  Example: enter 10 to keep all values in b under 10');
    nBound = str2num(str{1});
    str = inputdlg('Lastly, what would you like your accuracy to be?  For example, to receive 10^-5 accuracy, enter 0.00001.  I will generate a pop-up with the solution after this. Please maximize that window to see all the answers!');
    acc = str2num(str{1});
    b = randi(nBound, n, 1);
    
    [m,n] = size(A);
    [y,z] = size(b);
    x = [];
    if (m == n) && (m == y) && (z == 1)
        
       for j = 1:m
          x = [x;1];
       end
      
        answer = steepestDescent(A,b,x, acc);
        hList = uicontrol('Style','text','Position',[100 100 500 500]);
        set(hList,'String',num2str(answer));
        return;
        %disp(answer)
    else
        hList = uicontrol('Style','text','Position',[100 100 200 200]);
        set(hList,'String','You entered an invalid input.  Please close the program and try again');
        return;
    end
    
else
    hList = uicontrol('Style','text','Position',[100 100 200 200]);
    set(hList,'String','You entered an invalid input.  Please close the program and try again');
    return;
end

catch exception
    %fprintf('you entered a matrix that does not meet the criteria required.  Please try again');
    hList = uicontrol('Style','text','Position',[100 100 200 200]);
    set(hList,'String','You entered an invalid input.  Please close the program and try again');
    return;
end    