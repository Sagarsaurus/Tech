The source files have been included.  Please feel free to first put those files in the proper directory,
open those in Matlab and run the Project1.m script.  This script calls the algorithm itself.  
If you wish to run the algorithm itself, the algorithm takes 4 parameters.  Once it is in the right folder,
simply assign a value to A, a value to b, a value to x, and a value to accuracy (decimal for the desired accuracy).  
Then, call the algorithm simply by typing steepestDescent(A, b, x, accuracy).  Your results will print to the screen.

However, Project1.exe is a standalone application designed to be run instead of the source files.
The source files will still perform the same actions as the standalone application (Project1.exe).  
Project1.exe however will be quicker to run.  Give it some time to open, it can take a while.

MATLAB Compiler

1. Prerequisites for Deployment of Project1.exe

. Verify the MATLAB Compiler Runtime (MCR) is installed and ensure you    
  have installed version 7.17 (R2012a).   

. If the MCR is not installed, do following:
  (1) enter
  
      >>mcrinstaller
      
      at MATLAB prompt. This MCR Installer command displays the 
      location of the MCR Installer.

  (2) run the MCR Installer.

Or download Windows 64bit version of MCR from the MathWorks website:

   http://www.mathworks.com/products/compiler/

   If there is difficulty in finding the compiler on that website, please use this one instead:
   
   http://www.mathworks.com/products/compiler/mcr/index.html

   Install the proper MCR (version 7.17, R2012a) for your operating system.

   You may then run Project1.exe.  
  
   
For more information about the MCR and the MCR Installer, see 
�Working With the MCR� in the MATLAB Compiler User�s Guide.    


NOTE: You will need administrator rights to run MCRInstaller. 


2. Running Project1.exe
  
   Once the MCR is installed, double click (or open) Project1.exe.  It may take a few moments 
   (a minute and a half at worst) to open.





