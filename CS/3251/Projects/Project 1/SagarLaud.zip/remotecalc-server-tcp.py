import socket, sys

#load command line arguments
arguments = sys.argv

#host and port using command line arguments
host = ''
port = int(arguments[1])

#create socket with tcp protocol
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'

#bind
try:
    serverSocket.bind((host, port))
except:
    print "failed bind"
    sys.exit()

print 'was able to bind successfully'

#listen on port for connection
serverSocket.listen(5)
print 'listening for values'

#accept connection if possible
while True:

    conn,addr = serverSocket.accept()

    print 'Connected with ' + addr[0] + ':' + str(addr[1])

    #receive values that are sent
    value = conn.recv(256)

    #break message into distinct values
    value = value.split()

    #check if operation is recognized. if it is, perform operation, check that it fits in 2 bytes, and send response
    if int(value[1]) <0 or int(value[2]) < 0:
            toSend = "make sure both values are non-negative"

    elif value[0]=='multiply':

        if int(value[1]) * int(value[2]) > 65535:
            toSend = "result requires more than 2 bytes"
        else:
            toSend = int(value[1]) * int(value[2])

    elif value[0]=='add':
        if int(value[1]) + int(value[2]) > 65535:
            toSend = "result requires more than 2 bytes"
        else:
            toSend = int(value[1]) + int(value[2])
    else:
        toSend = "invalid operation"

    conn.sendall('Response from Server: '+str(toSend))
#close connection and socket
conn.close()
serverSocket.close()

