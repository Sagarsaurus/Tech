Sagar Laud
slaud3@gatech.edu
CS 3251, Section B, Programming Assignment 1 - Socket Basics

Four files have been submitted: remotecalc-tcp.py, remotecalc-udp.py, remotecalc-server-tcp.py, and remotecalc-server-udp.py.
The first two files, remotecalc-tcp.py and remotecalc-udp.py are the client sides of the project.  As per the names, remotecalc-tcp.py
uses tcp to communicate with the tcp server, remotecalc-server-tcp.py.  Likewise, remotecalc-udp.py uses udp to communicate with the udp
server, remotecalc-server-udp.py.  All files are written in python and were created and tested on 32 bit Linux Mint 17.  This was also 
created using python version 2.7.6.

In order to run the files as desired, determine whether you wish to test the tcp or udp protocol.  If you would like to test tcp, start
off by running the remotecalc-server-tcp.py.  Determine which port you would like to use, for our sake we will call it PORT.  Then, simply
run it by typing 'python remotecalc-server-tcp.py PORT'.  Upon doing this, simply run the tcp client to send a message to the server.  Do 
this by using the same port used for starting the server.  Then, determine which instruction you would like to run (either multiply or add).
Let us refer to this as OPERATION.  Finally, determine the two non-negative integers you would like to send to the server.  Let us call these
A and B.  So, once the server has started, simply run 'python 127.0.0.1:PORT OPERATION A B'.  You should either receive a response or an error
message from the server.  The server will remain running till you run a keyboard interrupt to stop it so run as many commands as you would like
with the client and then terminate the server.

Now, to run it with udp, start up the server exactly as you did with tcp.  To do so, choose a port, which we will refer to as PORT.  And run
'python remotecalc-server-udp.py PORT'.  Now, your server will be running.  You may now send messages to the server.  To do this, use the same 
command as with tcp with one minor change: replace remotecalc-tcp.py with remotecalc-udp.py.  The rest of the logic stays the same in regards to
OPERATION as well as A and B.  So, run 'python remotecalc-udp.py OPERATION A B' and you will receive either a response or an error message from 
the server.  That being said, there is a difference as this is udp.  Because this does not wait for a connection to necessarily be established,
we will allow for a timeout.  So, if no response is heard from the server within 2 seconds, the client will ask you to either enter 'retry' to 
resend the message or enter 'exit' to halt all execution.  The server will need to be stopped manually via a keyboard interrupt as before.

Known limitations of this involve using a fixed message size.  These files allow for messages of upto 256 bytes.  In addition, the server will
never return a value that requires greater than 2 bytes to represent.  UDP of course does not require for any acknowledges in regards to a message
being sent so there may be packet loss resulting in sending the message multiple times.  Finally, the server will only handle add or multiply instructions.
