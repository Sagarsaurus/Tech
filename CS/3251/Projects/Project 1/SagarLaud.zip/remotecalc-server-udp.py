import socket, sys

#read command line arguments
arguments = sys.argv

host = ''
port = int(arguments[1])

#initialize socket for udp
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
print 'Socket created'

#bind
try:
    serverSocket.bind((host, port))
except:
    print "failed bind"
    sys.exit()

print 'was able to bind successfully'

#keep looping waiting for item to be sent
while True:
    data = serverSocket.recvfrom(256)

    message = data[0]

    message = message.split()

    #determine operation and reply accordingly, return invalid operation/say result fails because of size of number
    if int(message[1]) <0 or int(message[2]) < 0:
            toSend = "make sure both values are non-negative"

    elif message[0]=='multiply':
        if int(message[1]) * int(message[2]) > 65535:
            toSend = "result requires more than 2 bytes"
        else:
            toSend = int(message[1]) * int(message[2])

    elif message[0]=='add':
        if int(message[1]) + int(message[2]) > 65535:
            toSend = "result requires more than 2 bytes"
        else:
            toSend = int(message[1]) + int(message[2])
    else:
        toSend = "invalid operation"

    serverSocket.sendto('Response from Server: '+str(toSend), data[1])

#close socket
serverSocket.close()