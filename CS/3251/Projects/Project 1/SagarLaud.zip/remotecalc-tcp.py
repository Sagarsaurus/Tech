import socket, sys

#read in all command line arguments
argument = sys.argv

if len(argument)<6:
    print 'not enough arguments present'
    sys.exit()
elif len(argument)>6:
    print 'too many arguments present'
    sys.exit()

if argument[1]=='remotecalc-udp':
    print 'using wrong protocol, this is tcp'
    sys.exit()

#see if we can create a socket using tcp, if not, exit
try:
    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except socket.error, error:
    print error    
    sys.exit()

print "Created tcp socket successfully"

#split host and port into separate items
ip_info = argument[2].split(":")

#establish connection with host and port
try:
    clientSocket.connect((ip_info[0], int(ip_info[1])))
except socket.error, error:
    print "connection could not be established. make sure your server is started"
    sys.exit()

#attempt to send message.  If there was an error, print it and exit
try:
    clientSocket.sendall(argument[3]+' '+argument[4]+ ' '+argument[5])
except socket.error, error:
    print error
    sys.exit()

print 'message was sent successfully'

#receive message
returned = clientSocket.recv(256)

#print message
print returned

#close socket
clientSocket.close()