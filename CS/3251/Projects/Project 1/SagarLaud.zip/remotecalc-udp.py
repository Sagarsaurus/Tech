import socket, sys

#read in command line arguments
argument = sys.argv

if len(argument)<6:
    print 'not enough arguments present'
    sys.exit()
elif len(argument)>6:
    print 'too many arguments present'
    sys.exit()


if argument[1]=='remotecalc-tcp':
    print 'using wrong protocol, this is udp'
    sys.exit()

#establish socket using udp, print error if it occurs
try:
    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
except socket.error, error:
    print error
    sys.exit()

print "Created udp socket successfully"

#split host and port into individual items
ip_info = argument[2].split(":")

#define overall message
message = argument[3]+' '+argument[4]+ ' '+argument[5]

#define loop to attempt to send message but allow for retrying
retry = True
while retry:
    returned = None
    try:
        #send message
        clientSocket.sendto(message, (ip_info[0], int(ip_info[1])))
        #endTime = time.time()+2
        clientSocket.settimeout(2)
        #check for response for two seconds
        try:
            #if message is returned, print it
            returned = clientSocket.recvfrom(256)
            print returned[0]
            retry = False
        except socket.timeout:
            #if no response, ask to either retry or quit
            decision = raw_input("No response from server with 2 seconds.  Enter 'retry' to resend message or 'exit' to exit: ")
            if decision=='retry':
                continue
            elif decision=='exit':
                print 'exiting'
                retry = False

    except socket.error, error:
        print error
        sys.exit()
#close socket after execution
clientSocket.close()