<?php
//put this at the top of each file: include('include.php');

	function dbconnect() {
		$link = mysql_connect('localhost', 'cs4400_Group_39', 'gwFBaN5o');
		if (!$link) 
		{
			die('Could not connect: ' . mysql_error());
		}
		mysql_select_db('cs4400_Group_39');
		//echo 'Connected successfully';
	}
	
	function dbclose()
	{
		mysql_close($link);
	}
?>

<!DOCTYPE html>
<html>
<head>

<style>
body{
	font-family: sans-serif;
}

a{
	text-decoration: none;
	color: #FFFFFF;
	background-color: #22B1EC;
	padding: 10px;
	width:200px;
	display: block;
}

a.edit_selector {
	align: center;
	height:20px;
	width:20px;
}

td{
	padding: 10px;
}

h3{
	color: #22B1EC;
}

input[type="button"], input[type="submit"]
{
	color: #FFFFFF;
	width:120px;
	margin-left:35px;
	display:block;
	background-color: #22B1EC;
	border: none;
	padding: 10px;
}

table thead th{
	height: 30px;
	color: #FFFFFF;
	vertical-align: bottom;
	text-align: left;
	background-color: #22B1EC;
	padding: 10px;	
	border-top-left-radius: 15px 15px;
	border-top-right-radius: 15px 15px;
}

table{
	height: 30px;
	vertical-align: bottom;
	text-align: left;
	background-color: #FFFFFF;
	padding: 5px;	
	border-top-left-radius: 15px 15px;
	border-top-right-radius: 15px 15px;
	margin: 15px;
}

</style>
</head>