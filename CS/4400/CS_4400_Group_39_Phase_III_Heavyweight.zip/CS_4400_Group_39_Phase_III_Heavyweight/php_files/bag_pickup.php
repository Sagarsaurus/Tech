<?php include('include.php');?>
<!----------------------------------------------------------------------------------------------------------------------->
<!--------------------------------------------Figure 4: Family Bag Pickup ----------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<h3>Family Bag Pickup</h3>
<?php
	dbconnect();
	
	$cid = $_GET['id'];
	if($cid == '') $cid = $_POST['id'];
	
	$sql = "SELECT bag FROM client WHERE client.cid = $cid";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	$bagName = $row['bag'];
	echo $bagName; 
	
	$sql = "SELECT product, current_qty FROM holds WHERE bag = '$bagName'";
	$result = mysql_query($sql);
	
	echo '<table><thead><th>Product</th><th>Quantity</th></thead>';
	while ($row = mysql_fetch_array($result))
	{
		echo '<tr>';
		echo '<td>' . $row['product'] . '</td>';
		echo '<td>' . $row['current_qty'] . '</td>';
		echo '</tr>';
	}
	echo '</table>';
	
	if($_POST['bag_pickup_submit'] == 'Pick Up')
	{
		$sql = 'INSERT into pickup_transaction(date) VALUES (CURDATE())';
		$result = mysql_query($sql);

		$sql = "INSERT into pickup(bag, cid, pid) VALUES ('$bagName', '$cid', LAST_INSERT_ID())";
		$result = mysql_query($sql);
		
		$sql = "SELECT * FROM holds WHERE bag = '$bagName'";
		$result = mysql_query($sql);
		while ($row = mysql_fetch_array($result))
		{
			$pickup_product = $row['product'];
			$pickup_qty = $row['current_qty'];
			$update_sql = "UPDATE product SET qty_on_hand = qty_on_hand - $pickup_qty WHERE name = '$pickup_product'";
			$temp_result = mysql_query($update_sql);
		}
	}
	
	dbclose();
?>
<form action="bag_pickup.php" method="post">
	<input type="hidden" name="id" value="<?php echo $cid?>" />
	<input type="submit" name="bag_pickup_submit" value="Pick Up" />
</form>
<br/>
<a href="home.php">Return to home page</a>
