<?php include('include.php');?>
<html>
<body>
<h3>Grocery List Report</h3>
<?php

	dbconnect();

	$sql = 'SELECT product, SUM(current_qty) as qty, SUM(last_month_qty) as last_month_quantity FROM holds GROUP BY product';
	$result = mysql_query($sql);
	echo '<table><thead><th>Product</th><th>Quantity</th><th>Last Month Quantity</th></thead>';
		while ($row = mysql_fetch_array($result))
		{
			echo '<tr>';
			echo '<td>' . $row['product'] . '</td>';
			echo '<td>' . $row['qty'] . '</td>';
			echo '<td>' . $row['last_month_quantity'] . '</td>';
			echo '</tr>';
		}
	echo '</table>';
	dbclose();
?>
<br/>
<a href="home.php">Return to home page</a>

</body>
</html>
