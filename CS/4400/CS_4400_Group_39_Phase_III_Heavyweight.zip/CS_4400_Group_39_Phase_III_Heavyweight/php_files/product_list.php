<?php include('include.php');?>
<html>
<body>
<h3>Product List</h3>

<form action="product_list.php" method="post">
<table>
<tr><td>Product: </td><td><input type="text" width=30 name="product" /></td></tr>
<tr><td>&nbsp; </td><td><input type="submit" name="search_product" value="Search" /></td></tr>
<tr><td>&nbsp; </td><td><input type="submit" name="search_product" value="Show All" /></td></tr>
</table>
</form>

<?php
	dbconnect();
	
	$search = '';
	if($_POST['search_product'] == 'Search') $search = $_POST['product'];
	if($_POST['search_product'] == 'Show All') $search = '';
	
	$sql = 'SELECT name, cost, qty_on_hand FROM product WHERE name LIKE "%'.$search.'%"';
	$result = mysql_query($sql);
	echo '<table><thead><th>Product Name</th><th>Quantity</th><th>Cost Per Unit</th></thead>';
		while ($row = mysql_fetch_array($result))
		{
			echo '<tr>';
			echo '<td>' . $row['name'] . '</td>';
			echo '<td>' . $row['qty_on_hand'] . '</td>';
			echo '<td>' . $row['cost'] . '</td>';
			echo '</tr>';
		}
	echo '</table>';
	dbclose();
?>
<br/>
<a href="home.php">Return to home page</a>

</body>
</html>

