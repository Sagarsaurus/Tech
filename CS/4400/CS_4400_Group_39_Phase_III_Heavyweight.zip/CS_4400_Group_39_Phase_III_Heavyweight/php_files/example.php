<?php include('include.php');?>
<p>Hi there!</p> <!--paragraph tags test-->

<table>
	<thead>
		<th>
			Col 1
		</th>
		<th>
			Col 2
		</th>
	</thead>
	<tr>
		<td>
			data 1
		</td>
		<td>
			data 2
		</td>
	</tr>
	<tr>
		<td>
			data 3
		</td>
		<td>
			data 4
		</td>
	</tr>
</table>

<hr /> <!-- the <hr /> tag inserts a horizonal rule -->

<?php //begining of php code

	echo 'The echo command prints things to the webpage <br /><br />'; //the <br /> tags insert html line breaks
	
	$x = 42; //All php variables begin with the dollar sign
	
	echo "Concatination is done using a period: " . $x . '<br /><br />';
	
	function increment($var)
	{
		$var++;
		return $var;
	}
	
	
	echo "this is the value of x is $x <br/>";
	echo 'increment(5) = ' . increment(5) . ' <br /><br />';

	//get variables
	//https://academic-php.cc.gatech.edu/groups/cs4400_Group_39/index.php?id=7&name=Kaitlan
	echo 'id is: ' . $_GET['id'];
	echo '<br />name is: ' . $_GET['name'];
?> <!--end of php code-->


<table>
	<thead>
		<th>
			Name
		<th>
		<th>
			Email
		<th>
	</thead>
<?php
	$link = mysql_connect('localhost', 'cs4400_Group_39', 'gwFBaN5o');
	if (!$link) 
	{
		die('Could not connect: ' . mysql_error());
	}
	mysql_select_db('cs4400_Group_39');
	echo 'Connected successfully';
	
	
	$sql = "SELECT * FROM user";
	$result = mysql_query($sql);
	while ($row = mysql_fetch_array($result))
	{
		echo '<tr>';
		echo '<td>' . $row['username'] .'</td>';
		echo '<td>' . $row['email'] . '</td>';
		echo '</tr>';
	}
	
	mysql_close($link);
?> 
</table>
