<?php include('include.php');?>
<!----------------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------Figure 2: Home-------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<h3>Home</h3>
<table>
<tr>
	<td><a href="pickup_signin.php">Pickups</a></td>
	<td><a href="bag_list.php">Bags</a></td>
	<td><a href="add_dropoff.php">Dropoffs</a></td>
</tr>
<tr>
	<td><a href="client.php">Clients</a></td>
	<td><a href="service_report.php">Service Reports</a></td>
	<td><a href="inventory.php">Products/Inventory</a></td>
</tr>
</table>