<?php include('include.php');?>

<h3>Add Client</h3>
<form action="new_family.php" method="post">
<table>
<tr>
	<td>Bag Type: </td>
	
	<td>
		<select name="bag_type">
			<?php
				dbconnect();
				$sql = "SELECT * FROM bag";
				$result = mysql_query($sql);
				
				while ($row = mysql_fetch_array($result))
				{
					echo '<option value ="'.$row['name'].'">'.$row['name'].'</option>';
				}
				dbclose();
			?>
		</select>
	</td>
</tr>
<tr><td>Pick Up Day (Two digit value): </td><td><input type="text" width=30 name="pickup_day" /></td></tr>
<tr><td>First Name: </td><td><input type="text" width=30 name="first_name" /></td></tr>
<tr><td>Last Name: </td><td><input type="text" width=30 name="last_name" /></td></tr>
<tr><td>Gender (M or F): </td><td><input type="text" width=30 name="gender" /></td></tr>
<tr><td>Date of birth (mmddyyyy): </td><td><input type="text" width=30 name="dob" /></td></tr>
<tr><td>Street: </td><td><input type="text" width=30 name="street" /></td></tr>
<tr><td>Apartment Number: </td><td><input type="text" width=30 name="apt_num" /></td></tr>
<tr><td>City: </td><td><input type="text" width=30 name="city" /></td></tr>
<tr><td>State: </td><td><input type="text" width=30 name="state" /></td></tr>
<tr><td>Zipcode: </td><td><input type="text" width=30 name="zip" /></td></tr>
<tr><td>Telephone: </td><td><input type="text" width=30 name="phone" /></td></tr>
<tr>
	<td>Financial Aid: </td>
	
	<td>
		<select name="fin_aid">
			<?php
				dbconnect();
				$sql = "SELECT * FROM financial_aid";
				$result = mysql_query($sql);
				
				while ($row = mysql_fetch_array($result))
				{
					echo '<option value ="'.$row['type'].'">'.$row['name'].' - '.$row['type'].'</option>';
				}
				dbclose();
			?>
		</select>
	</td>
</tr>
<tr><td>Start Date: </td><td><input type="text" width=30 name="start_date" /></td></tr>
<tr><td>&nbsp; </td><td><input type="submit" name="new_client_submit" value="Save Client" /></td></tr>

<?php
if($_POST['new_client_submit'] == 'Save Client')
{
	dbconnect();
	
	$bag_type = $_POST['bag_type'];
	$pickup_day = $_POST['pickup_day'];
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$gender = $_POST['gender'];
	$dob = $_POST['dob'];
	$street = $_POST['street'];			
	$apt_num = $_POST['apt_num'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zip = $_POST['zip'];
	$phone = $_POST['phone'];
	$fin_aid = $_POST['fin_aid'];
	$start_date = $_POST['start_date'];
	
	$sql = "SELECT * FROM product";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	$source = $row['source_id'];


	
	$sql = "INSERT into client( first_name, last_name, phone, bag, pickup_day, start_date, dob, gender, street, city, state, zip, apt) 
VALUES ( '$first_name', '$last_name', '$phone', '$bag_type', '$pickup_day', '$start_date', '$dob', '$gender', '$street', '$city', '$state', '$zip', '$apt_num')";
	$result = mysql_query($sql);
	echo $sql;	

	$sql = "INSERT into has_aid(client_id, financial_aid_id) VALUES (LAST_INSERT_ID(), '$fin_aid')";
	$result = mysql_query($sql);
	#needs to be fixed, LAST_INSERT_ID does not match cid
	#header("Location: add_family_mem.php");
	dbclose();
}
?>
</table>
</form>
