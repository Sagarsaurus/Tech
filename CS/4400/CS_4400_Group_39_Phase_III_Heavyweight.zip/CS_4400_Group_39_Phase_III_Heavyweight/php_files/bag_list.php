<?php include('include.php');?>
<!----------------------------------------------------------------------------------------------------------------------->
<!-------------------------------------------------figure 9: Bag list---------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<h3>Bag List</h3>
<?php
	dbconnect();
	
	$sql = "SELECT * FROM bag_view";
	$result = mysql_query($sql);
	
	echo '<table><thead><th>View/Edit Bag</th><th>Bag</th><th>Cost</th><th>Total Clients</th><th>Total Items</th></thead>';
	while ($row = mysql_fetch_array($result))
	{
		echo '<tr>';
		echo '<td><a class="edit_selector" href="view_edit_bag.php?bag='.$row['bag'].'">&oplus;</a></td>';
		echo '<td>' . $row['bag'] . '</td>';
		echo '<td>' . $row['cost'] . '</td>';
		echo '<td>' . $row['total_clients'] . '</td>';
		echo '<td>' . $row['total_items'] . '</td>';
		echo '</tr>';
	}
	echo '</table>';
	
	
	dbclose();
?>

<a href="home.php">Return to home page</a>