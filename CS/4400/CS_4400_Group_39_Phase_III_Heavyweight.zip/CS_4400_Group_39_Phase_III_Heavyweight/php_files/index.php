<?php include('include.php');?>
<!----------------------------------------------------------------------------------------------------------------------->
<!------------------------------------------------Figure 1: Login-------------------------------------------------------->
<!----------------------------------------------------------------------------------------------------------------------->
<h3>Login</h3>
<form action="index.php" method="post">
<table>
<tr><td>Username: </td><td><input type="text" width=30 name="username" /></td></tr>
<tr><td>Password: </td><td><input type="password" width=30 name="password" /></td></tr>
<tr><td>&nbsp; </td><td><input type="submit" name="login_submit" value="Login" /></td></tr>
</table>
</form>

<?php
if($_POST['login_submit'] == 'Login')
{
	dbconnect();
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$sql = 'SELECT * FROM user WHERE username = "' . $username . '" AND password = "' . $password . '"';
	
	$result = mysql_query($sql);
	if(mysql_num_rows($result) == 1) 
	{
		echo 'login success!';
		header("Location: home.php");
		dbclose();
		die();
	}
	else 
	{	
		echo 'login failed - bad credentials.';
	}
	
	dbclose();
}
?>
</body>
</html>
