<?php include('include.php');?>

<h3>Client</h3>
<table>
<tr>
	<td><a href="add_client.php">New Client</a></td>
	<td><a href="client_list.php">Search Clients</a></td>
	<td><a href="family_list.php">Family List</a></td>
</tr>

</table>

<a href="home.php">Return to home page</a>

