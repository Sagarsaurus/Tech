<?php include('include.php');?>

<h3>Family List</h3>
<form action="family_list.php" method="post">
<table>
<tr><td>Last Name: </td><td><input type="text" width=30 name="name" /></td><td>Telephone: </td><td><input type="text" width=30 name="number" /></td></tr>
<tr><td>&nbsp; </td><td><input type="submit" name="family_search_submit" value="Submit" /></td></tr>
</table>
</form>

<?php
if($_POST['family_search_submit'] == 'Submit')
{
	dbconnect();
	
	$name = $_POST['name'];
	$number = $_POST['number'];
	
	
	$sql = 'SELECT c.cid, c.first_name, c.last_name, COUNT(p.cid) AS size, CONCAT(apt, " ", street, ", ", city, ", ",state, " ", zip) AS address, c.phone, start_date FROM client c LEFT OUTER JOIN people p ON c.cid = p.cid WHERE c.last_name = "' . $name . '" AND c.phone = "' . $number .'" GROUP BY p.cid ';
	
	$result = mysql_query($sql);

	if(mysql_num_rows($result) == 1) 
	{
		echo '<table border = 1><thead><th>Last Name</th><th>First Name</th><th>Size</th><th>Address</th><th>Telephone</th><th>Start Date</th></thead>';
			while ($row = mysql_fetch_array($result))
			{
				echo '<tr>';
				echo '<td>' . $row['first_name'] . '</td>';
				echo '<td>' . $row['last_name'] . '</td>';
				echo '<td>' . $row['size'] . '</td>';
				echo '<td>' . $row['address'] . '</td>';
				echo '<td>' . $row['phone'] . '</td>';
				echo '<td>' . $row['start_date'] . '</td>';
				echo '</tr>';
			}
		echo '</table>';
		#echo '<a href="home.php">Return to home page</a>';
		dbclose();
	}
	else 
	{	
		echo 'Sorry, that family does not exist.';
	}
	
	dbclose();
}
?>
<br/>
<a href="home.php">Return to home page</a>

</body>
</html>
