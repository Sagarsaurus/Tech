<?php include('include.php');?>
<html>
<body>
<h3>Monthly Service Report</h3>
<?php

	dbconnect();

	$sql = 'SELECT * FROM monthly_service_report';
	$result = mysql_query($sql);
	echo '<table><thead><th>Week</th><th># of Households</th><th>Under 18 Years</th><th>18-64 Years</th><th>65 Years and Older</th><th>Total People</th><th>Food Cost ($)</th></thead>';
		while ($row = mysql_fetch_array($result))
		{
			echo '<tr>';
			echo '<td>' . $row['week'] . '</td>';
			echo '<td>' . $row['households'] . '</td>';
			echo '<td>' . $row['minors'] . '</td>';
			echo '<td>' . $row['adults'] . '</td>';
			echo '<td>' . $row['seniors'] . '</td>';
			echo '<td>' . $row['total_people'] . '</td>';
			echo '<td>' . $row['monthly_cost'] . '</td>';
			echo '</tr>';
		}
	echo '</table>';
	dbclose();
?>
<br/>
<a href="home.php">Return to home page</a>

</body>
</html>

