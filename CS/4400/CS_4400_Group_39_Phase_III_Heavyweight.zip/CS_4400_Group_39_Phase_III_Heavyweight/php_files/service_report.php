<?php include('include.php');?>
<html>
<body>
<h3> Service Reports</h3>
<a href="monthly_service_report.php">Monthly Service Report</a><br/><br/>
<a href="grocery_list_report.php">Grocery List Report</a><br/><br/><br/>
<a href="home.php">Return to home page</a>
</body>
</html>
