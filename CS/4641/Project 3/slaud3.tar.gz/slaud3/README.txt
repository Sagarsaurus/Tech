For this project I used the Weka Machine Learning Library once again, same as in project 1.  I upgraded to version 3.7.12 this time.  
To run any of the experiments, make sure to install the student-filters package as it does not come pre-installed.
Install it via the package manager and then running all tests should be straightforward from there.

Sagar
