For this project I used ABAGAIL and modifed some of the code.  I have included all of the code in the ABAGAIL directory.  Please import this into Eclipse as a project and
run CongressTest.java, ContinuousPeaksTest.java, KnapsackTest.java, and TravellingSalesmanTest.java to have the results output in the format that I did.  The latter 3 files
will run all iterations and output everything needed.  CongressTest.java however was used for the Neural Networks portion in Part 1 and as a result, that file must be run
5 times for each set of training iterations.  To change the number of training iterations, simply change the global variable at the top.  In addition, this is currently configured
to test on the Training Set.  To test on the Testing set, simply change the loop at line 63 of the code to be "for(int j = 288; j < instances.length; j++) {" and this will cause it
to test on the Testing Set.

Sagar
