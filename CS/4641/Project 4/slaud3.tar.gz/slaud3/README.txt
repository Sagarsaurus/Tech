For this project, the RL Library from CMU was used.  To run this code, please go within the Code folder, into the RL_Sim Folder, and execute the jarfile
that is in that directory.  To open any of the mazes used, select an algorithm to run, click Load Maze and select a maze from the mazes directory in RL_SIM.
Modify any parameters desired and run the algorithm.
