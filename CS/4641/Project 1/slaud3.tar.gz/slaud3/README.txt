For this project, I used the WEKA Machine Learning Tool.  I used the tool with the parameters specified in the writeup (and the data.xlsx file) with the datasets that are included in this archive.

For decision trees, the J48 algorithm was used.
For Boosting, AdaBoost was used in conjunction with J48.
For Neural Networks, a MultiLayerPerceptron was used.
For kNN, the IBk algorithm was used.
For SVM, the SMO algorithm was used.

All algorithms were run with varying parameters as explained in the paper and shown in the data.
