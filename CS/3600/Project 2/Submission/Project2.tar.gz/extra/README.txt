The extra problem that was created was the eight queens problem.  AA - HH each represent columns (from left to right)
to make for a total of 8 columns.  Each column has a value that can be assigned which represents the row that the queen
will occupy.  The constraints that were used are self-explanatory and have been added into BinaryCSP.py.

Thanks!
Sagar Laud
